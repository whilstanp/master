//
//  ViewController.swift
//  helloworld
//
//  Created by IOS on 09/03/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var nametf: UITextField!
        @IBOutlet weak var agetf: UITextField!
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField==nametf){print("name")}
        else if(textField==agetf){print("age")}
        buttonpressed(0)
        return textField.resignFirstResponder()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func buttonpressed(_ sender: Any) {
        let name = nametf.text!
        let age = agetf.text!
        print("Hi \(name), \(age)")
        let a = UIAlertController(title:"Welcome",message: "Hi \(name), \(age)",preferredStyle:.alert)
        let b = UIAlertAction(title: "OK", style: .default, handler: nil)
        a.addAction(b)
        present(a, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

