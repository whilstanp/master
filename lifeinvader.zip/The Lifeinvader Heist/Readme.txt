Hey there! Here are the instrutions of 
using The Lifeinvader Heist Mod By Rugz007!

Keys: 
F9 To Start the menu

How to Install:
1) Put all files in the "scripts" folder of GTA V 
2) Enjoy the mod!

Instructions: 
When mod  is activated,just go near the blips. No keys no nothing.
Just a key to activated Mod Menu :) 

Bugs: 
Lifeinvader Blip Route disappears after reaching at a point on highway


contact:
Mail - dsweb007@gmail.com
Website - www.gaemstudio.weebly.com
Patreon - 

Thank you for downloading my mod :D 