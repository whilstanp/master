This is an alpha release. Anything is subject to change.
Do not upload to anywhere, and do not include RAGE Plugin Hook in your plugin releases, without prior written permission.

You can find the licenses for the libraries used by RAGE Plugin Hook in the 'Licenses' folder.

Installation:
Put everything into the game folder, except the 'SDK' and 'Licenses' folders, then run RAGEPluginHook.exe.

For developers:
Reference SDK\RagePluginHookSDK.dll in your plugins.
For development, we recommend running the game in windowed borderless mode.

For documentation, visit http://ragepluginhook.net and go to the Documentation tab.
The documentation tab also has a page with images of all Ped models, and a list of all 35000+ animations.

Example plugins can be found in "SDK\Example plugins". You will need to re-add the reference to SDK\RagePluginHookSDK.dll.
Please note that this is an alpha release, and will contain bugs. Please report any and all issues at http://forums.ragepluginhook.net

Need help? Visit http://forums.ragepluginhook.net
Want to help others? Visit http://forums.ragepluginhook.net

Thank you.



Hit F4 in-game to open the console.
Type "help" (without the quotes) and press enter to see a list of all commands and variables.
You can make a text file named startup.rphs file to specify commands to run when the game starts.



Thanks to Leftas, cpast, Kal74, Albo1125, LtFlash and whomever else have helped us test support for retail versions of the game.
Thanks to you, for using RAGE Plugin Hook.

Special thanks to Alexander Blade for bringing us native hashes, saving us hours of extra work!