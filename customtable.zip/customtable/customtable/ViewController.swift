//
//  ViewController.swift
//  customtable
//
//  Created by IOS on 04/05/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tv: UITableView!
    var data:[Dictionary<String,String>]=[]
    override func viewDidLoad() {
        super.viewDidLoad()
        tv.delegate=self
        tv.dataSource=self
        let list=Bundle.main.path(forResource:"contacts",ofType:"plist")
        if let rawData=NSArray(contentsOfFile:list!){
            data=rawData as! [Dictionary<String,String>]
        }else{print("data read fail")}
        tv.reloadData()
        for i in 0..<data.count{
            for (k,v) in data[i]{
                print("\(i) = \(k), \(v)")
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let c = tv.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        let d = data[indexPath.row]
        c.name.text=d["name"]
        c.phone.text=d["company"]
        c.company.text=d["phone"]
        return c
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }

    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

