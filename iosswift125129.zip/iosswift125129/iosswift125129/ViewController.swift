//
//  ViewController.swift
//  iosswift125129
//
//  Created by IOS on 11/05/18.
//  Copyright © 2018 IOS. All rights reserved.
//
import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var inputuser: UITextField!
    @IBOutlet weak var inputpw: UITextField!
    @IBOutlet weak var sbmt: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let d = UserDefaults.standard
        let hasVW = d.bool(forKey:"hasVW")
        if(hasVW){
            welcomeLabel.text="Welcome back!"
        }
        else{
            welcomeLabel.text="Welcome to my app, I hope you enjoy it!"
            d.set(true,forKey:"hasVW")
            d.synchronize()
        }
        var user:String?=""
        var pw:String?=""
        if let u = d.string(forKey:"x"){
            user = u
        }
        if let p = d.string(forKey:"y"){
            pw = p
        }
        inputuser.text=user
        inputpw.text=pw
        if(user != ""){
            submitPressed(0)
        }
    }
    @IBAction func submitPressed(_ sender: Any) {
        let d = UserDefaults.standard
        d.set(inputuser.text,forKey:"x")
        d.set(inputpw.text,forKey:"y")
        let url=URL(string:"https://opensource.petra.ac.id/~m26414117/test.php?u=\(inputuser.text!)&p=\(inputpw.text!)");
        do{
            let d=try String(contentsOf:url!)
            if(d=="logged in!"){
performSegue(withIdentifier:"homepagesegue",sender:"self")}
            else{print(d)}
        }
        catch{
            print("parse data failed")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


