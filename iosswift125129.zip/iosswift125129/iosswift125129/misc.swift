//
//  misc.swift
//  iosswift125129
//
//  Created by IOS on 18/05/18.
//  Copyright © 2018 IOS. All rights reserved.
//
import Foundation
class misc{
    static func jsonparse(_ url:String)->[Dictionary<String,String>]{
    do{
        let u = URL(string: url)
        let data = try Data(contentsOf: u!)
        if let json:NSArray = try JSONSerialization.jsonObject(with:data,options:JSONSerialization.ReadingOptions.mutableContainers) as? NSArray{
        if let result = json as? [[String:String]]{
        return result}
        }
    }catch{}
    return []
    }
}
