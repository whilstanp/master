The mod allows you to create 30 bodyguards. Bodyguards have different weapons and a lot of health (10000 of health).
Bodyguards will not writhe and will not die at the same time. They can fight for a very long time.
All bodyguards follow the main character. These are 29 representatives of Grove and Trevor. Trevor has equipment and laser weapons.
Trevor is distinguished by invincibility.

Also, this mod increases the health of the main character and gives him a laser weapon.

Bodyguards can only be created once per game. If you want to create bodyguards again, you will need to load the saved game again.
This is the first version of the mod. Maybe I'll do other options later. I say thank you, if you make a video with this mod.

Usage:
Press O to spawn 30 Bodyguards. For the script you need: Script Hook V, Script Hook V Dot Net.

This version is 1.1.
Changes:

One of the bodyguards now uses throwing weapons (flares and snowballs).

Added two members with fire extinguishers. They do not fight, but only extinguish the bodyguards and the main character.

Also, Trevor now has a fire extinguisher.