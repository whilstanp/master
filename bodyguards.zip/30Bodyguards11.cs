﻿using GTA;
using GTA.Native;
using GTA.Math;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace General
{
    public class Class1 : Script
    {
        public Class1()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(100);
                Game.Player.Character.MaxHealth = 7500;
                Game.Player.Character.Health = 7500;
                Game.Player.Character.Armor = 100;
                Game.Player.Character.Weapons.Give(WeaponHash.UnholyHellbringer, 5500, true, true);
                Game.Player.Character.Weapons.Select(WeaponHash.UnholyHellbringer);

                GTA.PedGroup plgroup = Game.Player.Character.CurrentPedGroup;
                GTA.Native.Function.Call(GTA.Native.Hash.SET_PED_AS_GROUP_LEADER, Game.Player.Character, plgroup);
                GTA.Native.Function.Call(Hash.SET_GROUP_FORMATION_SPACING, plgroup, 2.0F);

                Ped grove = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, grove, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove, 100);
                grove.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove.CanBeTargetted = true;
                grove.MaxHealth = 10000;
                grove.Health = 10000;
                grove.Accuracy = 100;
                grove.Weapons.Give(WeaponHash.CombatPistol, 1000, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove, 5, true);
                grove.Task.FightAgainstHatedTargets(50.0F);
                grove.AddBlip();
                grove.CurrentBlip.IsFriendly = true;
                grove.CurrentBlip.Color = BlipColor.GreenDark;
                grove.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove, false);
                grove.CanWrithe = false;
                grove.AlwaysKeepTask = true;

                Ped grove2 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove2.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, grove2, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove2, 100);
                grove2.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove2.CanBeTargetted = true;
                grove2.MaxHealth = 10000;
                grove2.Health = 10000;
                grove2.Accuracy = 100;
                grove2.Weapons.Give(WeaponHash.HeavyPistol, 1200, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove2, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove2, 5, true);
                grove2.Task.FightAgainstHatedTargets(50.0F);
                grove2.AddBlip();
                grove2.CurrentBlip.IsFriendly = true;
                grove2.CurrentBlip.Color = BlipColor.GreenDark;
                grove2.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove2, false);
                grove2.CanWrithe = false;
                grove2.AlwaysKeepTask = true;

                Ped trevor = World.CreatePed(new Model(PedHash.Trevor), Game.Player.Character.Position.Around(4.0F));
                trevor.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, trevor, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, trevor, 100);
                trevor.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                trevor.CanBeTargetted = true;
                trevor.MaxHealth = 10000;
                trevor.Health = 10000;
                trevor.IsInvincible = true;
                trevor.Accuracy = 100;
                trevor.ShootRate = 100;
                trevor.Weapons.Give(WeaponHash.UnholyHellbringer, 5500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, trevor, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, trevor, 5, true);
                trevor.Task.FightAgainstHatedTargets(50.0F);
                trevor.AddBlip();
                trevor.CurrentBlip.IsFriendly = true;
                trevor.CurrentBlip.Color = BlipColor.Trevor;
                trevor.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, trevor, false);
                trevor.CanWrithe = false;
                
                trevor.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);
                GTA.Native.Function.Call(Hash.SET_PED_COMPONENT_VARIATION, trevor, 3, 2, 0, 0);
                GTA.Native.Function.Call(Hash.SET_PED_COMPONENT_VARIATION, trevor, 4, 2, 0, 0);
                GTA.Native.Function.Call(Hash.SET_PED_COMPONENT_VARIATION, trevor, 5, 1, 0, 0);
                GTA.Native.Function.Call(Hash.SET_PED_PROP_INDEX, trevor, 1, 11, 0, 1);

                Ped grove3 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove3.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, grove3, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove3, 100);
                grove3.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove3.CanBeTargetted = true;
                grove3.MaxHealth = 10000;
                grove3.Health = 10000;
                grove3.Accuracy = 100;
                grove3.Weapons.Give(WeaponHash.MarksmanPistol, 2200, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove3, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove3, 5, true);
                grove3.Task.FightAgainstHatedTargets(50.0F);
                grove3.AddBlip();
                grove3.CurrentBlip.IsFriendly = true;
                grove3.CurrentBlip.Color = BlipColor.GreenDark;
                grove3.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove3, false);
                grove3.CanWrithe = false;
                grove3.AlwaysKeepTask = true;

                Ped grove4 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove4.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, grove4, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove4, 100);
                grove4.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove4.CanBeTargetted = true;
                grove4.MaxHealth = 10000;
                grove4.Health = 10000;
                grove4.Accuracy = 100;
                grove4.Weapons.Give(WeaponHash.MarksmanPistol, 2200, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove4, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove4, 5, true);
                grove4.Task.FightAgainstHatedTargets(50.0F);
                grove4.AddBlip();
                grove4.CurrentBlip.IsFriendly = true;
                grove4.CurrentBlip.Color = BlipColor.GreenDark;
                grove4.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove4, false);
                grove4.CanWrithe = false;
                grove4.AlwaysKeepTask = true;

                Ped grove5 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove5.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, grove5, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove5, 100);
                grove5.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove5.CanBeTargetted = true;
                grove5.MaxHealth = 10000;
                grove5.Health = 10000;
                grove5.Accuracy = 100;
                grove5.Weapons.Give(WeaponHash.VintagePistol, 2200, true, true);
                grove5.Weapons.Give(WeaponHash.SniperRifle, 7, true, true);
                grove5.Weapons.Select(WeaponHash.SniperRifle);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove5, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove5, 5, true);
                grove5.Task.FightAgainstHatedTargets(50.0F);
                grove5.AddBlip();
                grove5.CurrentBlip.IsFriendly = true;
                grove5.CurrentBlip.Color = BlipColor.GreenDark;
                grove5.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove5, false);
                grove5.CanWrithe = false;
                grove5.AlwaysKeepTask = true;

                Ped grove6 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove6.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_AS_GROUP_MEMBER, grove6, plgroup);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove6, 100);
                grove6.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove6.CanBeTargetted = true;
                grove6.MaxHealth = 10000;
                grove6.Health = 10000;
                grove6.Accuracy = 100;
                grove6.Weapons.Give(WeaponHash.APPistol, 2200, true, true);
                grove6.Weapons.Give(WeaponHash.AssaultRifle, 12, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove6, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove6, 5, true);
                grove6.Task.FightAgainstHatedTargets(50.0F);
                grove6.AddBlip();
                grove6.CurrentBlip.IsFriendly = true;
                grove6.CurrentBlip.Color = BlipColor.GreenDark;
                grove6.NeverLeavesGroup = true;
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove6, false);
                grove6.CanWrithe = false;
                grove6.AlwaysKeepTask = true;

                while (true)
                {
                    Wait(0);

                    foreach (Ped pedonfire in World.GetNearbyPeds(trevor.Position, 30.0F))
                    {
                        while (true)
                        {
                            Wait(0);
                            if (pedonfire.IsOnFire && pedonfire.RelationshipGroup == Game.Player.Character.RelationshipGroup)
                            {
                                trevor.Weapons.RemoveAll();
                                Wait(100);
                                trevor.BlockPermanentEvents = true;
                                Wait(200);
                                trevor.AlwaysKeepTask = true;
                                Wait(100);
                                trevor.Weapons.Give(WeaponHash.FireExtinguisher, 10000, true, true);
                                Wait(100);
                                trevor.Weapons.Select(WeaponHash.FireExtinguisher);
                                Wait(100);
                                trevor.Task.RunTo(pedonfire.Position.Around(2.0F));
                                Wait(2000);
                                trevor.Task.ShootAt(pedonfire, 7000, FiringPattern.FullAuto);
                                Wait(7500);
                                trevor.Weapons.Give(WeaponHash.UnholyHellbringer, 5500, true, true);
                                Wait(100);
                                trevor.Weapons.Select(WeaponHash.UnholyHellbringer);
                                Wait(500);
                                trevor.BlockPermanentEvents = false;
                            }
                        }
                    }

                }
            }
        }
    }

    public class Grove7 : Script
    {
        public Grove7()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(100);
                Ped grove7 = World.CreatePed(new Model(PedHash.Famdnf01GMY), Game.Player.Character.Position.Around(4.0F));
                grove7.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove7, 100);
                grove7.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove7.CanBeTargetted = true;
                grove7.MaxHealth = 10000;
                grove7.Health = 10000;
                grove7.Accuracy = 100;
                grove7.Weapons.Give(WeaponHash.MarksmanPistol, 5200, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove7, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove7, 5, true);
                grove7.Task.FightAgainstHatedTargets(50.0F);
                grove7.AddBlip();
                grove7.CurrentBlip.IsFriendly = true;
                grove7.CurrentBlip.Color = BlipColor.GreenDark;
                grove7.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove7, false);
                grove7.CanWrithe = false;
                grove7.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove7.Position.DistanceTo(Game.Player.Character.Position) > 9.0F)
                    {

                        grove7.Task.RunTo(Game.Player.Character.Position.Around(4.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }


    public class Class2 : Script
    {
        public Class2()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(100);
                Ped grove8 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove8.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove8, 100);
                grove8.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove8.CanBeTargetted = true;
                grove8.MaxHealth = 10000;
                grove8.Health = 10000;
                grove8.Accuracy = 100;
                grove8.Weapons.Give(WeaponHash.HeavyShotgun, 1200, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove8, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove8, 5, true);
                grove8.Task.FightAgainstHatedTargets(50.0F);
                grove8.AddBlip();
                grove8.CurrentBlip.IsFriendly = true;
                grove8.CurrentBlip.Color = BlipColor.GreenDark;
                grove8.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove8, false);
                grove8.CanWrithe = false;
                grove8.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove8.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove8.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class3 : Script
    {
        public Class3()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(200);
                Ped grove9 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove9.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove9, 100);
                grove9.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove9.CanBeTargetted = true;
                grove9.MaxHealth = 10000;
                grove9.Health = 10000;
                grove9.Accuracy = 100;
                grove9.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove9, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove9, 5, true);
                grove9.Task.FightAgainstHatedTargets(50.0F);
                grove9.AddBlip();
                grove9.CurrentBlip.IsFriendly = true;
                grove9.CurrentBlip.Color = BlipColor.GreenDark;
                grove9.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove9, false);
                grove9.CanWrithe = false;
                grove9.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove9.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove9.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class4 : Script
    {
        public Class4()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(300);
                Ped grove10 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove10.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove10, 100);
                grove10.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove10.CanBeTargetted = true;
                grove10.MaxHealth = 10000;
                grove10.Health = 10000;
                grove10.Accuracy = 100;
                grove10.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove10, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove10, 5, true);
                grove10.Task.FightAgainstHatedTargets(50.0F);
                grove10.AddBlip();
                grove10.CurrentBlip.IsFriendly = true;
                grove10.CurrentBlip.Color = BlipColor.GreenDark;
                grove10.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove10, false);
                grove10.CanWrithe = false;
                grove10.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove10.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove10.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class5 : Script
    {
        public Class5()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(400);
                Ped grove11 = World.CreatePed(new Model(PedHash.Families01GFY), Game.Player.Character.Position.Around(4.0F));
                grove11.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove11, 100);
                grove11.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove11.CanBeTargetted = true;
                grove11.MaxHealth = 10000;
                grove11.Health = 10000;
                grove11.Accuracy = 100;
                grove11.Weapons.Give(WeaponHash.FlareGun, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove11, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove11, 5, true);
                grove11.Task.FightAgainstHatedTargets(50.0F);
                grove11.AddBlip();
                grove11.CurrentBlip.IsFriendly = true;
                grove11.CurrentBlip.Color = BlipColor.GreenDark;
                grove11.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove11, false);
                grove11.CanWrithe = false;
                grove11.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove11.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove11.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class6 : Script
    {
        public Class6()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(500);
                Ped grove12 = World.CreatePed(new Model(PedHash.Families01GFY), Game.Player.Character.Position.Around(4.0F));
                grove12.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove12, 100);
                grove12.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove12.CanBeTargetted = true;
                grove12.MaxHealth = 10000;
                grove12.Health = 10000;
                grove12.Accuracy = 100;
                grove12.Weapons.Give(WeaponHash.VintagePistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove12, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove12, 5, true);
                grove12.Task.FightAgainstHatedTargets(50.0F);
                grove12.AddBlip();
                grove12.CurrentBlip.IsFriendly = true;
                grove12.CurrentBlip.Color = BlipColor.GreenDark;
                grove12.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove12, false);
                grove12.CanWrithe = false;
                grove12.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove12.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove12.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class7 : Script
    {
        public Class7()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(600);
                Ped grove13 = World.CreatePed(new Model(PedHash.Famfor01GMY), Game.Player.Character.Position.Around(4.0F));
                grove13.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove13, 100);
                grove13.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove13.CanBeTargetted = true;
                grove13.MaxHealth = 10000;
                grove13.Health = 10000;
                grove13.Accuracy = 100;
                grove13.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove13, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove13, 5, true);
                grove13.Task.FightAgainstHatedTargets(50.0F);
                grove13.AddBlip();
                grove13.CurrentBlip.IsFriendly = true;
                grove13.CurrentBlip.Color = BlipColor.GreenDark;
                grove13.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove13, false);
                grove13.CanWrithe = false;
                grove13.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove13.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove13.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class8 : Script
    {
        public Class8()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(700);
                Ped grove14 = World.CreatePed(new Model(PedHash.Famfor01GMY), Game.Player.Character.Position.Around(4.0F));
                grove14.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove14, 100);
                grove14.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove14.CanBeTargetted = true;
                grove14.MaxHealth = 10000;
                grove14.Health = 10000;
                grove14.Accuracy = 100;
                grove14.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove14, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove14, 5, true);
                grove14.Task.FightAgainstHatedTargets(50.0F);
                grove14.AddBlip();
                grove14.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 0);
                grove14.CurrentBlip.IsFriendly = true;
                grove14.CurrentBlip.Color = BlipColor.GreenDark;
                grove14.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove14, false);
                grove14.CanWrithe = false;
                grove14.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove14.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove14.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class9 : Script
    {
        public Class9()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(800);
                Ped grove15 = World.CreatePed(new Model(PedHash.Famfor01GMY), Game.Player.Character.Position.Around(4.0F));
                grove15.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove15, 100);
                grove15.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove15.CanBeTargetted = true;
                grove15.MaxHealth = 10000;
                grove15.Health = 10000;
                grove15.Accuracy = 100;
                grove15.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove15, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove15, 5, true);
                grove15.Task.FightAgainstHatedTargets(50.0F);
                grove15.AddBlip();
                grove15.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 0);
                grove15.CurrentBlip.IsFriendly = true;
                grove15.CurrentBlip.Color = BlipColor.GreenDark;
                grove15.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove15, false);
                grove15.CanWrithe = false;
                grove15.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove15.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove15.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }


    public class Class10 : Script
    {
        public Class10()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(900);
                Ped grove16 = World.CreatePed(new Model(PedHash.Famdnf01GMY), Game.Player.Character.Position.Around(4.0F));
                grove16.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove16, 100);
                grove16.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove16.CanBeTargetted = true;
                grove16.MaxHealth = 10000;
                grove16.Health = 10000;
                grove16.Accuracy = 100;
                grove16.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove16, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove16, 5, true);
                grove16.Task.FightAgainstHatedTargets(50.0F);
                grove16.AddBlip();
                grove16.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);
                grove16.CurrentBlip.IsFriendly = true;
                grove16.CurrentBlip.Color = BlipColor.GreenDark;
                grove16.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove16, false);
                grove16.CanWrithe = false;
                grove16.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove16.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove16.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class11 : Script
    {
        public Class11()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1000);
                Ped grove17 = World.CreatePed(new Model(PedHash.Famdnf01GMY), Game.Player.Character.Position.Around(4.0F));
                grove17.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove17, 100);
                grove17.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove17.CanBeTargetted = true;
                grove17.MaxHealth = 10000;
                grove17.Health = 10000;
                grove17.Accuracy = 100;
                grove17.Weapons.Give(WeaponHash.Pistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove17, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove17, 5, true);
                grove17.Task.FightAgainstHatedTargets(50.0F);
                grove17.AddBlip();
                grove17.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);
                grove17.CurrentBlip.IsFriendly = true;
                grove17.CurrentBlip.Color = BlipColor.GreenDark;
                grove17.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove17, false);
                grove17.CanWrithe = false;
                grove17.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove17.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove17.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class12 : Script
    {
        public Class12()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1100);
                Ped grove18 = World.CreatePed(new Model(PedHash.Famdnf01GMY), Game.Player.Character.Position.Around(4.0F));
                grove18.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove18, 100);
                grove18.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove18.CanBeTargetted = true;
                grove18.MaxHealth = 10000;
                grove18.Health = 10000;
                grove18.Accuracy = 100;
                grove18.Weapons.Give(WeaponHash.APPistol, 3500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove18, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove18, 5, true);
                grove18.Task.FightAgainstHatedTargets(50.0F);
                grove18.AddBlip();
                grove18.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);
                grove18.CurrentBlip.IsFriendly = true;
                grove18.CurrentBlip.Color = BlipColor.GreenDark;
                grove18.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove18, false);
                grove18.CanWrithe = false;
                grove18.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove18.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove18.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class13 : Script
    {
        public Class13()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1200);
                Ped grove19 = World.CreatePed(new Model(PedHash.Famdnf01GMY), Game.Player.Character.Position.Around(4.0F));
                grove19.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove19, 100);
                grove19.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove19.CanBeTargetted = true;
                grove19.MaxHealth = 10000;
                grove19.Health = 10000;
                grove19.Accuracy = 100;
                grove19.Weapons.Give(WeaponHash.BullpupShotgun, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove19, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove19, 5, true);
                grove19.Task.FightAgainstHatedTargets(50.0F);
                grove19.AddBlip();
                grove19.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);
                grove19.CurrentBlip.IsFriendly = true;
                grove19.CurrentBlip.Color = BlipColor.GreenDark;
                grove19.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove19, false);
                grove19.CanWrithe = false;
                grove19.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove19.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove19.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class14 : Script
    {
        public Class14()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1300);
                Ped grove20 = World.CreatePed(new Model(PedHash.Famdnf01GMY), Game.Player.Character.Position.Around(4.0F));
                grove20.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove20, 100);
                grove20.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove20.CanBeTargetted = true;
                grove20.MaxHealth = 10000;
                grove20.Health = 10000;
                grove20.Accuracy = 100;
                grove20.Weapons.Give(WeaponHash.HeavyPistol, 1500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove20, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove20, 5, true);
                grove20.Task.FightAgainstHatedTargets(50.0F);
                grove20.AddBlip();
                grove20.GiveHelmet(false, HelmetType.FiremanHelmet, 0);
                grove20.CurrentBlip.IsFriendly = true;
                grove20.CurrentBlip.Color = BlipColor.GreenDark;
                grove20.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove20, false);
                grove20.CanWrithe = false;
                grove20.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove20.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove20.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class15 : Script
    {
        public Class15()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1400);
                Ped grove21 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove21.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove21, 100);
                grove21.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove21.CanBeTargetted = true;
                grove21.MaxHealth = 10000;
                grove21.Health = 10000;
                grove21.Accuracy = 100;
                grove21.Weapons.Give(WeaponHash.SMG, 4500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove21, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove21, 5, true);
                grove21.Task.FightAgainstHatedTargets(50.0F);
                grove21.AddBlip();
                grove21.CurrentBlip.IsFriendly = true;
                grove21.CurrentBlip.Color = BlipColor.GreenDark;
                grove21.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove21, false);
                grove21.CanWrithe = false;
                grove21.AlwaysKeepTask = true;


                while (true)
                {
                    Wait(0);

                    if (grove21.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove21.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class16 : Script
    {
        public Class16()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1500);
                Ped grove22 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove22.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove22, 100);
                grove22.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove22.CanBeTargetted = true;
                grove22.MaxHealth = 10000;
                grove22.Health = 10000;
                grove22.Accuracy = 100;
                grove22.Weapons.Give(WeaponHash.CombatPistol, 2500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove22, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove22, 5, true);
                grove22.Task.FightAgainstHatedTargets(50.0F);
                grove22.AddBlip();
                grove22.CurrentBlip.IsFriendly = true;
                grove22.CurrentBlip.Color = BlipColor.GreenDark;
                grove22.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove22, false);
                grove22.CanWrithe = false;
                grove22.AlwaysKeepTask = true;
                grove22.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);


                while (true)
                {
                    Wait(0);

                    if (grove22.Position.DistanceTo(Game.Player.Character.Position) > 7.0F)
                    {

                        grove22.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class17 : Script
    {
        public Class17()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1600);
                Ped grove23 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove23.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove23, 100);
                grove23.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove23.CanBeTargetted = true;
                grove23.MaxHealth = 10000;
                grove23.Health = 10000;
                grove23.Accuracy = 100;
                grove23.Weapons.Give(WeaponHash.SniperRifle, 2500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove23, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove23, 5, true);
                grove23.Task.FightAgainstHatedTargets(100.0F);
                grove23.AddBlip();
                grove23.CurrentBlip.IsFriendly = true;
                grove23.CurrentBlip.Color = BlipColor.GreenDark;
                grove23.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove23, false);
                grove23.CanWrithe = false;
                grove23.AlwaysKeepTask = true;
                grove23.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);


                while (true)
                {
                    Wait(0);

                    if (grove23.Position.DistanceTo(Game.Player.Character.Position) > 8.0F)
                    {

                        grove23.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class18 : Script
    {
        public Class18()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1700);
                Ped grove24 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove24.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove24, 100);
                grove24.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove24.CanBeTargetted = true;
                grove24.MaxHealth = 10000;
                grove24.Health = 10000;
                grove24.Accuracy = 100;
                grove24.Weapons.Give(WeaponHash.SniperRifle, 2500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove24, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove24, 5, true);
                grove24.Task.FightAgainstHatedTargets(100.0F);
                grove24.AddBlip();
                grove24.CurrentBlip.IsFriendly = true;
                grove24.CurrentBlip.Color = BlipColor.GreenDark;
                grove24.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove24, false);
                grove24.CanWrithe = false;
                grove24.AlwaysKeepTask = true;
                grove24.GiveHelmet(false, HelmetType.FiremanHelmet, 0);


                while (true)
                {
                    Wait(0);

                    if (grove24.Position.DistanceTo(Game.Player.Character.Position) > 8.0F)
                    {

                        grove24.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class19 : Script
    {
        public Class19()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1800);
                Ped grove25 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove25.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove25, 100);
                grove25.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove25.CanBeTargetted = true;
                grove25.MaxHealth = 10000;
                grove25.Health = 10000;
                grove25.Accuracy = 100;
                grove25.Weapons.Give(WeaponHash.APPistol, 5500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove25, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove25, 5, true);
                grove25.Task.FightAgainstHatedTargets(100.0F);
                grove25.AddBlip();
                grove25.CurrentBlip.IsFriendly = true;
                grove25.CurrentBlip.Color = BlipColor.GreenDark;
                grove25.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove25, false);
                grove25.CanWrithe = false;
                grove25.AlwaysKeepTask = true;
                grove25.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);


                while (true)
                {
                    Wait(0);

                    if (grove25.Position.DistanceTo(Game.Player.Character.Position) > 8.0F)
                    {

                        grove25.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class20 : Script
    {
        public Class20()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(1900);
                Ped grove26 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove26.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove26, 100);
                grove26.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove26.CanBeTargetted = true;
                grove26.MaxHealth = 10000;
                grove26.Health = 10000;
                grove26.Accuracy = 100;
                grove26.Weapons.Give(WeaponHash.MiniSMG, 5500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove26, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove26, 5, true);
                grove26.Task.FightAgainstHatedTargets(100.0F);
                grove26.AddBlip();
                grove26.CurrentBlip.IsFriendly = true;
                grove26.CurrentBlip.Color = BlipColor.GreenDark;
                grove26.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove26, false);
                grove26.CanWrithe = false;
                grove26.AlwaysKeepTask = true;
                grove26.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 0);


                while (true)
                {
                    Wait(0);

                    if (grove26.Position.DistanceTo(Game.Player.Character.Position) > 8.0F)
                    {

                        grove26.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class21 : Script
    {
        public Class21()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(2000);
                Ped grove27 = World.CreatePed(new Model(PedHash.Famdd01), Game.Player.Character.Position.Around(4.0F));
                grove27.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove27, 100);
                grove27.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove27.CanBeTargetted = true;
                grove27.MaxHealth = 10000;
                grove27.Health = 10000;
                grove27.Accuracy = 100;
                grove27.Weapons.Give(WeaponHash.SNSPistol, 5500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove27, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove27, 5, true);
                grove27.Task.FightAgainstHatedTargets(100.0F);
                grove27.AddBlip();
                grove27.CurrentBlip.IsFriendly = true;
                grove27.CurrentBlip.Color = BlipColor.GreenDark;
                grove27.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove27, false);
                grove27.CanWrithe = false;
                grove27.AlwaysKeepTask = true;
                grove27.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 0);


                while (true)
                {
                    Wait(0);

                    if (grove27.Position.DistanceTo(Game.Player.Character.Position) > 8.0F)
                    {

                        grove27.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class22 : Script
    {
        public Class22()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(2100);
                Ped grove28 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove28.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove28, 100);
                grove28.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove28.CanBeTargetted = true;
                grove28.MaxHealth = 10000;
                grove28.Health = 10000;
                grove28.Accuracy = 100;
                grove28.Weapons.Give(WeaponHash.SNSPistol, 5500, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove28, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove28, 5, true);
                grove28.Task.FightAgainstHatedTargets(100.0F);
                grove28.AddBlip();
                grove28.CurrentBlip.IsFriendly = true;
                grove28.CurrentBlip.Color = BlipColor.GreenDark;
                grove28.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove28, false);
                grove28.CanWrithe = false;
                grove28.AlwaysKeepTask = true;
                grove28.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);


                while (true)
                {
                    Wait(0);

                    if (grove28.Position.DistanceTo(Game.Player.Character.Position) > 8.0F)
                    {

                        grove28.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                        Wait(4000);
                    }
                }
            }
        }
    }

    public class Class23 : Script
    {
        public Class23()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(2200);
                Ped grove29 = World.CreatePed(new Model(PedHash.Families01GFY), Game.Player.Character.Position.Around(4.0F));
                grove29.Task.ClearAllImmediately();
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ABILITY, grove29, 100);
                grove29.RelationshipGroup = Game.Player.Character.RelationshipGroup;
                grove29.CanBeTargetted = true;
                grove29.MaxHealth = 10000;
                grove29.Health = 10000;
                grove29.Accuracy = 100;
                grove29.Weapons.Give(WeaponHash.Flare, 1000, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove29, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove29, 5, true);
                grove29.Task.FightAgainstHatedTargets(100.0F);
                grove29.AddBlip();
                grove29.CurrentBlip.IsFriendly = true;
                grove29.CurrentBlip.Color = BlipColor.GreenDark;
                grove29.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove29, false);
                grove29.CanWrithe = false;
                grove29.AlwaysKeepTask = true;
                grove29.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);




                while (true)
                {
                    Wait(0);
                    
                    if (grove29.Position.DistanceTo(Game.Player.Character.Position) > 10.0F)
                    {
                        grove29.BlockPermanentEvents = true;
                        grove29.Task.RunTo(Game.Player.Character.Position.Around(2.0F));
                        Wait(4000);
                    }

                    foreach (Ped trg in World.GetNearbyPeds(grove29.Position, 150.0F))
                    {

                        if (trg.IsInCombat && trg.RelationshipGroup != Game.Player.Character.RelationshipGroup && grove29.Position.DistanceTo(Game.Player.Character.Position) < 30.0F)
                        {
                            grove29.BlockPermanentEvents = true;
                            grove29.Weapons.Give(WeaponHash.Flare, 1, true, true);
                            Wait(1000);
                            GTA.Native.Function.Call(Hash.TASK_THROW_PROJECTILE, grove29, trg.Position.X, trg.Position.Y, trg.Position.Z);
                            Wait(3000);
                            grove29.Weapons.Give(WeaponHash.Snowball, 5, true, true);
                            Wait(1000);
                            grove29.Task.RunTo(trg.Position.Around(15.0F));
                            Wait(4000);
                            GTA.Native.Function.Call(Hash._0x3523634255FC3318, grove29, "GENERIC_INSULT_HIGH", "g_f_y_families_01_black_mini_02", "SPEECH_PARAMS_FORCE_SHOUTED", 0);
                            GTA.Native.Function.Call(Hash.TASK_THROW_PROJECTILE, grove29, trg.Position.X, trg.Position.Y, trg.Position.Z);
                            Wait(2000);
                            GTA.Native.Function.Call(Hash.TASK_THROW_PROJECTILE, grove29, trg.Position.X, trg.Position.Y, trg.Position.Z);
                            Wait(1800);
                            GTA.Native.Function.Call(Hash.TASK_THROW_PROJECTILE, grove29, trg.Position.X, trg.Position.Y, trg.Position.Z);
                            Wait(1900);
                            GTA.Native.Function.Call(Hash._0x3523634255FC3318, grove29, "GENERIC_INSULT_HIGH", "g_f_y_families_01_black_mini_02", "SPEECH_PARAMS_FORCE_SHOUTED", 0);
                            GTA.Native.Function.Call(Hash.TASK_THROW_PROJECTILE, grove29, trg.Position.X, trg.Position.Y, trg.Position.Z);
                            Wait(1700);
                            GTA.Native.Function.Call(Hash.TASK_THROW_PROJECTILE, grove29, trg.Position.X, trg.Position.Y, trg.Position.Z);
                            Wait(1000);
                        }

                    }


                }
            }
        }
    }

    public class Class24 : Script
    {
        public Class24()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(2300);
                Ped grove30 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove30.Task.ClearAllImmediately();
                var firemanbg = World.AddRelationshipGroup("firemanbg");
                World.SetRelationshipBetweenGroups(Relationship.Respect, Game.Player.Character.RelationshipGroup, firemanbg);
                grove30.RelationshipGroup = firemanbg;
                grove30.MaxHealth = 10000;
                grove30.Health = 10000;
                grove30.Accuracy = 100;
                grove30.Weapons.Give(WeaponHash.FireExtinguisher, 10000, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove30, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove30, 5, true);
                grove30.AddBlip();
                grove30.CurrentBlip.IsFriendly = true;
                grove30.CurrentBlip.Color = BlipColor.Orange;
                grove30.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove30, false);
                grove30.CanWrithe = false;
                grove30.AlwaysKeepTask = true;
                grove30.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 1);
                grove30.IsFireProof = true;

                while (true)
                {
                    Wait(0);

                    if (grove30.Position.DistanceTo(Game.Player.Character.Position) > 9.0F)
                    {
                        grove30.BlockPermanentEvents = true;
                        grove30.Task.RunTo(Game.Player.Character.Position.Around(4.0F));
                        Wait(4000);
                    }

                    foreach (Ped pedonfire in World.GetNearbyPeds(grove30.Position, 30.0F))
                    {

                        if (pedonfire.IsOnFire && pedonfire.RelationshipGroup == Game.Player.Character.RelationshipGroup)
                        {
                            grove30.BlockPermanentEvents = true;
                            grove30.Task.RunTo(pedonfire.Position.Around(2.0F));
                            Wait(2000);
                            grove30.Task.ShootAt(pedonfire, 5000, FiringPattern.FullAuto);
                            Wait(5000);
                            grove30.Weapons.Give(WeaponHash.FireExtinguisher, 10000, true, true);
                            grove30.Weapons.Select(WeaponHash.FireExtinguisher);
                        }
                    }



                }
            }
        }
    }


    public class Class25 : Script
    {
        public Class25()
        {
            Tick += OnTick;

        }

        void OnTick(object sender, EventArgs e)
        {
            if (Game.IsKeyPressed(Keys.O))
            {
                Wait(2400);
                Ped grove31 = World.CreatePed(new Model(PedHash.Famca01GMY), Game.Player.Character.Position.Around(4.0F));
                grove31.Task.ClearAllImmediately();
                var firemanbg = World.AddRelationshipGroup("firemanbg");
                World.SetRelationshipBetweenGroups(Relationship.Respect, Game.Player.Character.RelationshipGroup, firemanbg);
                grove31.RelationshipGroup = firemanbg;
                grove31.MaxHealth = 10000;
                grove31.Health = 10000;
                grove31.Accuracy = 100;
                grove31.Weapons.Give(WeaponHash.FireExtinguisher, 10000, true, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove31, 46, true);
                GTA.Native.Function.Call(Hash.SET_PED_COMBAT_ATTRIBUTES, grove31, 5, true);
                grove31.AddBlip();
                grove31.CurrentBlip.IsFriendly = true;
                grove31.CurrentBlip.Color = BlipColor.Orange;
                grove31.Task.RunTo(Game.Player.Character.Position.Around(3.0F));
                GTA.Native.Function.Call(Hash.SET_PED_DIES_WHEN_INJURED, grove31, false);
                grove31.CanWrithe = false;
                grove31.AlwaysKeepTask = true;
                grove31.GiveHelmet(false, HelmetType.RegularMotorcycleHelmet, 2);
                grove31.IsFireProof = true;

                while (true)
                {
                    Wait(0);

                    if (grove31.Position.DistanceTo(Game.Player.Character.Position) > 12.0F)
                    {
                        grove31.BlockPermanentEvents = true;
                        grove31.Task.RunTo(Game.Player.Character.Position.Around(4.0F));
                        Wait(4000);
                    }

                    foreach (Ped pedonfire in World.GetNearbyPeds(grove31.Position, 30.0F))
                    {

                        if (pedonfire.IsOnFire && pedonfire.RelationshipGroup == Game.Player.Character.RelationshipGroup)
                        {
                            grove31.BlockPermanentEvents = true;
                            grove31.Task.RunTo(pedonfire.Position.Around(2.0F));
                            Wait(3000);
                            grove31.Task.ShootAt(pedonfire, 6000, FiringPattern.FullAuto);
                            Wait(6000);
                            grove31.Weapons.Give(WeaponHash.FireExtinguisher, 10000, true, true);
                            grove31.Weapons.Select(WeaponHash.FireExtinguisher);
                        }
                    }



                }
            }
        }
    }


}