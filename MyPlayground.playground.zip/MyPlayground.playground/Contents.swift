//: Playground - noun: a place where people can play
//nil -> purely null "" -> empty string, masi menempati tempat
//pada memori
import UIKit
//pemisah ribuan bisa dengan underscore
var str: String = "Hello, playground"
let str2: String = "another string" //variabel statis
//operasi bukan variabel tidak ditandai var/let
var integer: Int = 100
var decimal: Float = 12.5
integer = Int(decimal)
//tuples -> menyimpan beberapa data dengan tipe yang berbeda, cara kerja seperti array (ambil indeks)
let coordinates: (Float, Int) = (2.1, 3)
let x: Float = coordinates.0
let y: Int = coordinates.1
//pengambilan nilai (fetch) sesuai dengan peletakan (posisi) pada tuple (paling kiri indeks 0 kanan n)
let coordinates3d: (a: Int, b: Int, c: Int) = (2, 3, 1)
coordinates3d.a
coordinates3d.b
coordinates3d.c
let (a, _, c) = coordinates3d
a
c
1_000_000
let hourlyrate = 27.14
let hoursworked = 17.0 //int -> double
let totalcost = hourlyrate * hoursworked
let word = "hello"
let message = "\(word), my name is"
print("\(message)") //interpolation
let 👍🏻👀 = "🙋🏼‍♂️"
print("\(👍🏻👀)", terminator: "")
print("")
print("makanan","minuman", separator: ", ")
var ar: [String] = []
var twd = [[Int]]()
twd = [[1,2],[3,4]]
twd[1][1] //array dimensi kedua indeks kedua
ar.isEmpty //cek sebuah array kosong atau tidak
twd.append([5,6])

var expenses = ["bills": ["internet","electricity","heat"]]
for(type,reasons) in expenses{
for tagihan in reasons{
    print("\(tagihan)")}
}

func addnums(x: Int, y: Int) -> Int{
    return x+y;}
addnums(x:27345,y:62763)

func calctip(total: Float, tip_pct: Float = 0.15) -> Float{
    return total*tip_pct;}
calctip(total:122)
calctip(total:18.722,tip_pct:0.02294)

func calcarea(tinggi height: Int, lebar width: Int) -> Int{
    return height*width;} //variabel
calcarea(tinggi:29483,lebar:3856) //alias, mengacu kepada value
//yang sama -> variabel
//struct vs class -> struct membuat objek baru alokasi memori
//tersendiri per objek class sebaliknya karena refer pada alamat
//memori yang sama (ditimpa)
//variabel:tipe data? -> pengecekan apakah variabel yang
//bersangkutan bernilai null
//(variabel!) -> unwrap, jika sudah yakin isi variabel tidak null
//hilangkan tulisan optional pada output