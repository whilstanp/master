//
//  aidb.swift
//  iosproject
//
//  Created by IOS on 30/06/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit
import SQLite3
class aidb: UIViewController{
    //}, UITableViewDataSource, UITableViewDelegate{
    @IBOutlet weak var aidbtv: UITableView!
    var db:OpaquePointer?
    var ailist:[foe]=[]
    var stmt:OpaquePointer?
    let querystring = "INSERT INTO foe (nama,atk,def,hp,evade,critical,skill,mpskill,mpai,diff) VALUES (?,?,?,?,?,?,?,?,?,?)"
    /*if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
    let errmsg = String(cString: sqlite3_errmsg(db)!)
    print("error preparing insert: \(errmsg)")
    return
    }
    if sqlite3_bind_text(stmt, 1, name, -1, nil) != SQLITE_OK{
    let errmsg = String(cString: sqlite3_errmsg(db)!)
    print("failure binding name: \(errmsg)")
    return
    }
    if sqlite3_bind_int(stmt, 2, (powerRanking! as NSString).intValue) != SQLITE_OK{
    let errmsg = String(cString: sqlite3_errmsg(db)!)
    print("failure binding name: \(errmsg)")
    return
    }
    if sqlite3_step(stmt) != SQLITE_DONE {
    let errmsg = String(cString: sqlite3_errmsg(db)!)
    print("failure inserting hero: \(errmsg)")
    return
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ailist.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "cell")
        let asd: foe
        asd = ailist[indexPath.row]
        cell.textLabel?.text = asd.nama
        return cell
    }
    func readValues(){
        ailist.removeAll()
        let queryString = "SELECT * FROM foe"
        var stmt:OpaquePointer?
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return
        }
        while(sqlite3_step(stmt) == SQLITE_ROW){
            let id = sqlite3_column_int(stmt, 0)
            let name = String(cString: sqlite3_column_text(stmt, 1))
            //let powerrank = sqlite3_column_int(stmt, 2)
ailist.append(foe((setai.ainame.text!)!,Float(setai.aiatk.text!)!,Float(setai.aidef.text!)!,Float(setai.aihp.text!)!,Float(setai.aievade.text!)!,Float(setai.aicritical.text!)!,Int(setai.aiskilltype.text!)!,Float(setai.aiskillmp.text!)!,Float(setai.mpai.text!)!,Float(setai.aidiff.text!)!))
        }
        self.aidbtv.reloadData()
    }*/
    override func viewDidLoad() {
        super.viewDidLoad()
        /*let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("aidb.sqlite")
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("error opening database")
        }
        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS foe (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)", nil, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        }
        readValues()*/
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
