//
//  setplayer.swift
//  iosproject
//
//  Created by IOS on 30/06/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit
import SQLite3
class player{
    var nama:String=""
    var atk:Float=0
    var def:Float=0
    var hp:Float=0
    var evade:Float=0
    var critical:Float=0
    var initialhp:Float=0
    var skill:Int=0
    var mpskill:Float=0
    var playermp:Float=0
    var initialmp:Float=0
    init(_ n:String="", _ pa:Float=0, _ pd:Float=0, _ ph:Float=0, _ pe:Float=0, _ pc:Float=0, _ s:Int=0, _ mps:Float=0,
         _ mp1:Float=0, _ imp:Float=0) {
        nama = n
        atk = pa
        def = pd
        hp = ph
        evade = pe
        critical = pc
        initialhp = ph
        skill = s
        mpskill = mps
        playermp = mp1
        initialmp = mp1
    }
}
var a:player=player()
class setplayer: UIViewController {
    @IBOutlet weak var playername: UITextField!
    @IBOutlet weak var playerhp: UITextField!
    @IBOutlet weak var playeratk: UITextField!
    @IBOutlet weak var playerdef: UITextField!
    @IBOutlet weak var playercritical: UITextField!
    @IBOutlet weak var playerevade: UITextField!
    @IBOutlet weak var playerskilltype: UITextField!
    @IBOutlet weak var playermpskill: UITextField!
    @IBOutlet weak var playermp: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func aiconf(_ sender: Any) {
        let refreshAlert = UIAlertController(title: "Confirmation for AI chosen", message: "What're you gonna do..?", preferredStyle: UIAlertControllerStyle.alert)
        refreshAlert.addAction(UIAlertAction(title: "Create AI", style: .default, handler: { (action: UIAlertAction!) in
a=player(self.playername.text!,Float(self.playeratk.text!)!,Float(self.playerdef.text!)!,Float(self.playerhp.text!)!,Float(self.playerevade.text!)!,Float(self.playercritical.text!)!,Int(self.playerskilltype.text!)!,Float(self.playermpskill.text!)!,Float(self.playermp.text!)!)
            self.performSegue(withIdentifier: "setai", sender: self);
        }))
        refreshAlert.addAction(UIAlertAction(title: "Choose existing AI", style: .cancel, handler: { (action: UIAlertAction!) in
            self.performSegue(withIdentifier: "aidb", sender: self);
        }))
        present(refreshAlert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
