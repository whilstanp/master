//
//  setai.swift
//  iosproject
//
//  Created by IOS on 30/06/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit
import SQLite3
class foe{
    var nama:String=""
    var atk:Float=0
    var def:Float=0
    var hp:Float=0
    var evade:Float=0
    var critical:Float=0
    var initialhp:Float=0
    var skill:Int=0
    var mpskill:Float=0
    var mpai:Float=0
    var initialmp:Float=0
    var difficulty:Float=0
    init(_ n:String="", _ pa:Float=0, _ pd:Float=0, _ ph:Float=0, _ pe:Float=0, _ pc:Float=0, _ s:Int=0, _ mps:Float=0,
         _ mp1:Float=0, _ imp:Float=0, _ d:Float=0) {
        nama = n
        atk = pa
        def = pd
        hp = ph
        evade = pe
        critical = pc
        initialhp = ph
        skill = s
        mpskill = mps
        mpai = mp1
        initialmp = mp1
        difficulty = d
    }
}
var b:foe=foe()
class setai: UIViewController {
    @IBOutlet weak var aidiff: UITextField!
    @IBOutlet weak var ainame: UITextField!
    @IBOutlet weak var aihp: UITextField!
    @IBOutlet weak var aiatk: UITextField!
    @IBOutlet weak var aidef: UITextField!
    @IBOutlet weak var aicritical: UITextField!
    @IBOutlet weak var aievade: UITextField!
    @IBOutlet weak var aiskilltype: UITextField!
    @IBOutlet weak var aiskillmp: UITextField!
    @IBOutlet weak var mpai: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func aidbnav(_ sender: Any) {
b=foe(self.ainame.text!,Float(self.aiatk.text!)!,Float(self.aidef.text!)!,Float(self.aihp.text!)!,Float(self.aievade.text!)!,Float(self.aicritical.text!)!,Int(self.aiskilltype.text!)!,Float(self.aiskillmp.text!)!,Float(self.mpai.text!)!,Float(self.aidiff.text!)!)
        performSegue(withIdentifier: "aidb2", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
