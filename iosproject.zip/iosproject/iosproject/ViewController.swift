//
//  ViewController.swift
//  iosproject
//
//  Created by IOS on 08/05/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func sp(_ sender: Any) {
        self.performSegue(withIdentifier: "setplayer", sender: self);}
}

