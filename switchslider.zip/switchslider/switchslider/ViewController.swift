//
//  ViewController.swift
//  switchslider
//
//  Created by IOS on 23/03/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var slider1: UISlider!
    @IBOutlet weak var switchL: UILabel!
    @IBOutlet weak var sliderL: UILabel!
    @IBOutlet weak var sliderValueL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sliderChanged(_ sender: Any) {
        let s = sender as! UISlider
        sliderValueL.text = String(format: "%.5f",s.value)
    }
    
    @IBAction func switchChanged(_ sender: Any) {
        let s = sender as! UISwitch
        let e:[UIView] = [slider1,sliderL,sliderValueL]
        for i in 0..<e.count{
            e[i].isHidden = !s.isOn
        }
    }
}

