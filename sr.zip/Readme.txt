--- Main Installation ---
Place "Street Racing.dll" and the "StreetRaces" folder inside the "Grand Theft Auto V/scripts" folder. If you don't have that folder, create it.

Usage: Once ingame, go to any of the so-called Street Races. A blip will show all the races available. Once there, hit E.
Betting: enter the race on foot instead of a vehicle.

--- Optional: Race & Oponent creator ---
If you wish to create your own races and add new cars/opponents to the script, place the "Street Racing Race Editor.dll" file inside the "Grand Theft Auto V/scripts" folder.

Usage:
Use - to open the Car Saver menu.
Use + to open the Race Creator menu.

WARNING: They're both pretty much beta.