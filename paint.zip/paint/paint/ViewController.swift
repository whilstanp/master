//
//  ViewController.swift
//  paint
//
//  Created by sc-009 on 08/06/18.
//  Copyright © 2018 sc-009. All rights reserved.
//

import UIKit
import TouchDraw
class ViewController: UIViewController {
    @IBOutlet var tdv: TouchDrawView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func clicked(_ sender: Any) {
        tdv.undo();
    }
    
}

