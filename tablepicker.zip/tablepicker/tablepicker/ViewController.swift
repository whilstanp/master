//
//  ViewController.swift
//  tablepicker
//
//  Created by IOS on 06/04/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    let pickerdata:[String] = ["a","b"]
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if(pickerView == p1){
            return 1}
        else if(pickerView == p2){
            return 2}
        return -1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerdata.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component:Int) -> String? {
        return pickerdata[row]
    }

    @IBOutlet weak var p1: UIPickerView!
    @IBOutlet weak var p2: UIPickerView!
    @IBOutlet weak var dp: UIDatePicker!
    @IBAction func dateChanged(_ sender: Any) {
        let d = sender as? UIDatePicker
        print(d!.date)
        let dd = DateFormatter()
        dd.dateStyle = DateFormatter.Style.short
        dd.timeStyle = DateFormatter.Style.short
        print(dd.string(from: d!.date))
        M.alert(self, "date", dd.string(from: d!.date))
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

