//
//  M.swift
//  tablepicker
//
//  Created by IOS on 06/04/18.
//  Copyright © 2018 IOS. All rights reserved.
//

import Foundation
import UIKit
public class M{
    public static func alert(_ vc:UIViewController, _ title:String, _ msg:String)->Void{
        let al = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        let ok = UIAlertAction(title: str("ok"), style: .default, handler: nil)
        al.addAction(ok)
        vc.present(al, animated: true, completion: nil)
    }
    public static func str(_ n:String)->String{
        return NSLocalizedString(n, comment:"")
    }
}

